from ._logging import logger
log = logger.getChild('main')

log.info('main()')
